# mvvm-RWDevCon
MVVM in Practice - RWDevCon Session - raywenderlich.com

[![MVVM in Practice - RWDevCon Session](https://img.youtube.com/vi/sWx8TtRBOfk/0.jpg)](http://www.youtube.com/watch?v=sWx8TtRBOfk)